package com.springbootcrud.springbootcrud.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.springbootcrud.springbootcrud.model.Employee;
import com.springbootcrud.springbootcrud.repository.EmployeeRepository;

@Component
public class EmployeeDao {

	@Autowired
	EmployeeRepository er;
	
	
	public List<Employee> getData()
	{
		return er.findAll();
		
		
	}
	
	
	  public void saveData(Employee employee) {
	  
	  er.save(employee);
	  
	  }
	 
}
