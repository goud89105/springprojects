package com.springbootcrud.springbootcrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootcrud.springbootcrud.model.Employee;
import com.springbootcrud.springbootcrud.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	
	@Autowired
    EmployeeService es;
	
	@GetMapping("/get")
	public List<Employee> getData()
	{
		return es.getData();
		
		
		
	}
	@PostMapping("/save")
	public Employee saveData(@RequestBody Employee emloyee)
	{
		es.saveData(emloyee);
		return emloyee;
	}
}
