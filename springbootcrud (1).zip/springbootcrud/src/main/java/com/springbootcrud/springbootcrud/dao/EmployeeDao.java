package com.springbootcrud.springbootcrud.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.springbootcrud.springbootcrud.model.Employee;
import com.springbootcrud.springbootcrud.repository.EmployeeRepository;

@Component
public class EmployeeDao {

	@Autowired
	EmployeeRepository er;
	
	
	public List<Employee> getData()
	{
		return er.findAll();
		
		
	}
	
	
	  public List<Employee> saveData(List<Employee> employee) {
	  
	   er.saveAll(employee);
	  return er.findAll();
	  
	  }
	  
	  public List<Employee> deleteData(long id) {
		  er.deleteById(id);
		  return er.findAll();
		  }
	 public Employee updateData(long id,Employee employee) {
		Optional<Employee> e= er.findById(id);
			Employee e1=e.get();
			e1.setName(employee.getName());
			e1.setAddress(employee.getAddress());
			er.save(e1);
		return e1;
	 }
}
