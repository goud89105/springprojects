package com.springbootcrud.springbootcrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootcrud.springbootcrud.dao.EmployeeDao;
import com.springbootcrud.springbootcrud.model.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao ed;

	public List<Employee> getData() {
		return ed.getData();

	}

	public List<Employee> saveData(List<Employee> emloyee) {

		return ed.saveData(emloyee);

	}

	public List<Employee> deleteData(long id) {

		return ed.deleteData(id);
	}
	
	public Employee updateData(long id,Employee emloyee) {

		return ed.updateData(id,emloyee);
		
	}
}
