package com.mkyong.customer.service;

public interface CustomerService {
}
