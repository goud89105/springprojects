package com.bootwithjunitswagger.bootwithjunitswagger;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.bootwithjunitswagger.bootwithjunitswagger.model.Student;
import com.bootwithjunitswagger.bootwithjunitswagger.repository.StudentRepository;
import com.bootwithjunitswagger.bootwithjunitswagger.service.StudentService;







@SpringBootTest
public class StudentAppTest {

	@Autowired
	private StudentService studentService;

	@MockBean
	private StudentRepository repository;
	
	
	
	@Test
	public void getUsersTest() {
		when(repository.findAll()).thenReturn(Stream
				.of(new Student(376, "Danile","USA"), new Student(958, "Huy","UK")).collect(Collectors.toList()));
		assertEquals(2, studentService.getAllUsers().size());
	}

	
	@Test
	public void saveUserTest() {
		Student student = new Student(999, "Pranya","Pune");
		when(repository.save(student)).thenReturn(student);
		assertEquals(student, studentService.saveUser(student));
	}
	@Test
	public void deleteUserTest() {
		Student student = new Student(999, "Pranya","Pune");
		studentService.deleteUserById(student);
		verify(repository, times(1)).delete(student);
	}
	

	@Test
	public void getUserbyAddressTest() {
		String address = "Bangalore";
		when(repository.findByAddress(address))
				.thenReturn(Stream.of(new Student(376, "Danile","USA")).collect(Collectors.toList()));
		assertEquals(1, studentService.getUserbyAddress(address).size());
	}
}
