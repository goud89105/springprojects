package com.bootwithjunitswagger.bootwithjunitswagger.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bootwithjunitswagger.bootwithjunitswagger.model.Student;
import com.bootwithjunitswagger.bootwithjunitswagger.service.StudentService;



@RestController
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	StudentService studentService;

	

	@GetMapping("/fetchAll")
	public List<Student> getAllUsers() {
		return studentService.getAllUsers();
	}
	
	@PostMapping("/create")
	public Student saveUser(@RequestBody Student student) {
		return studentService.saveUser(student);
	}
	
	@GetMapping("/getUserByAddress/{address}")
	public List<Student> findUserByAddress(@PathVariable String address) {
		return studentService.getUserbyAddress(address);
	}

	@DeleteMapping("/delete")
	public Student deleteUserById(@RequestBody Student student) {
	 studentService.deleteUserById(student);
	 
		return student;
	}

	
}
