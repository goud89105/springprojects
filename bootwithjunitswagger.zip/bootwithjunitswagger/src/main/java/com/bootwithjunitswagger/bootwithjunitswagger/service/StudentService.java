package com.bootwithjunitswagger.bootwithjunitswagger.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bootwithjunitswagger.bootwithjunitswagger.model.Student;
import com.bootwithjunitswagger.bootwithjunitswagger.repository.StudentRepository;


@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepository;
	

	 
	public List<Student> getAllUsers(){
		return studentRepository.findAll();
		
	}
	
	public List<Student> getUserbyAddress(String address) {
		return studentRepository.findByAddress(address);
	}
	public void deleteUserById(Student student)
	{
		 studentRepository.delete(student);;
		
	}
	
	public Student saveUser(Student student)
	{
		return studentRepository.save(student);
		
	}
}
